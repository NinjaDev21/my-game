=== CTL 3 Cards Monte ===
Tags: 	cards, casino game, find the lady, gambling, gambling game, html5 casino game, html5 gambling, poker, sweepstakes, three card
Requires at least: 4.3
Tested up to: 4.3

Add 3 Cards Monte to CTL Arcade plugin

== Description ==
Add 3 Cards Monte to CTL Arcade plugin